'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
library = [
    {"title": "Kunci Kesuksesan", "author": "raja indera", "year": 2008},
    {"title": "kesabaran yang mendalam", "author": "Evos Jagar", "year": 2012},
    {"title": "aku ada di sini untukmu", "author": "Evos Jagar", "year": 1984},
    {"title": "pencari cinta sejati", "author": "raja indera", "year": 2024},
    {"title": "Pengantar Jaringan Komputer", "author": "Bsk Alok", "year": 2023}
]

def search_books_by_title(keyword):
    results = []
    for book in library:
        if keyword.lower() in book["title"].lower():
            results.append(book)
    return results

def search_books_by_author(keyword):
    results = []
    for book in library:
        if keyword.lower() in book["author"].lower():
            results.append(book)
    return results

def search_books_by_year(year):
    results = []
    for book in library:
        if book["year"] == year:
            results.append(book)
    return results

def display_books(books):
    if not books:
        print("Tidak ada buku yang ditemukan.")
    else:
        print("Buku yang ditemukan:")
        for book in books:
            print(f"Judul: {book['title']}, Penulis: {book['author']}, Tahun: {book['year']}")

def main():
    while True:
        print("\nMenu Pencarian Buku")
        print("1. Cari buku berdasarkan judul")
        print("2. Cari buku berdasarkan penulis")
        print("3. Cari buku berdasarkan tahun rilis")
        print("4. Keluar")
        choice = input("Pilih menu: ")

        if choice == '1':
            keyword = input("Masukkan kata kunci judul buku: ")
            results = search_books_by_title(keyword)
            display_books(results)
        elif choice == '2':
            keyword = input("Masukkan nama penulis: ")
            results = search_books_by_author(keyword)
            display_books(results)
        elif choice == '3':
            year = int(input("Masukkan tahun rilis: "))
            results = search_books_by_year(year)
            display_books(results)
        elif choice == '4':
            print("Keluar dari program...")
            break
        else:
            print("Pilihan tidak valid. Silakan coba lagi.")

if __name__ == "__main__":
    main()
